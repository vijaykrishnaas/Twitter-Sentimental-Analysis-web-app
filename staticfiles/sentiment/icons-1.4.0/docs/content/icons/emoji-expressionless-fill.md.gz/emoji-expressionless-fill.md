---
title: Emoji expressionless fill
layout: icon
categories:
  - Emoji
tags:
  - emoticon
  - neutral
  - unphased
---
