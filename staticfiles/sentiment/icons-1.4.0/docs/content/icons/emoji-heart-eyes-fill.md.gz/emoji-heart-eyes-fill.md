---
title: Emoji heart eyes fill
layout: icon
categories:
  - Emoji
tags:
  - emoticon
  - heart
  - love
---
