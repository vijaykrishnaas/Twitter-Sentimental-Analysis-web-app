---
title: Emoji heart eyes
layout: icon
categories:
  - Emoji
tags:
  - emoticon
  - heart
  - love
---
