---
title: Emoji smile upside down fill
layout: icon
categories:
  - Emoji
tags:
  - emoticon
  - sarcasm
---
