---
title: File earmark binary fill
categories:
  - Files and folders
tags:
  - doc
  - document
  - binary
  - source
---
