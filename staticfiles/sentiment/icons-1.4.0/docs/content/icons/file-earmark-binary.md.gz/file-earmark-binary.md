---
title: File earmark binary
categories:
  - Files and folders
tags:
  - doc
  - document
  - binary
  - source
---
