---
title: File earmark easel
categories:
  - Files and folders
tags:
  - slides
  - presentation
  - powerpoint
  - keynote
---
