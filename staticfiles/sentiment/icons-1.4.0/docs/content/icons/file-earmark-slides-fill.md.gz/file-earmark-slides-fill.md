---
title: File earmark slides fill
categories:
  - Files and folders
tags:
  - presentation
  - keynote
  - powerpoint
---
