---
title: File easel fill
categories:
  - Files and folders
tags:
  - slides
  - presentation
  - powerpoint
  - keynote
---
