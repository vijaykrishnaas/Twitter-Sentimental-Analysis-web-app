---
title: File excel
categories:
  - Files and folders
tags:
  - doc
  - document
  - spreadsheet
  - excel
  - table
---
