---
title: File slides
categories:
  - Files and folders
tags:
  - presentation
  - keynote
  - powerpoint
---
