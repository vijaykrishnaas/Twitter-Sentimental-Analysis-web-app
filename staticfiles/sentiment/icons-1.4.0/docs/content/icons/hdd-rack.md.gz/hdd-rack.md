---
title: Hdd rack
categories:
  - Devices
tags:
  - "hard drive"
  - "hard disk"
  - ssd
  - drive
  - server
---
