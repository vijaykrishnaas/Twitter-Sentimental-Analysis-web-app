---
title: Hdd stack
categories:
  - Devices
tags:
  - "hard drive"
  - "hard disk"
  - ssd
  - drive
  - server
---
