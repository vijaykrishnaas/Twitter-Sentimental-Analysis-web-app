---
title: Journal bookmark fill
categories:
  - Files and folders
tags:
  - file
  - folder
  - journal
  - notebook
---
