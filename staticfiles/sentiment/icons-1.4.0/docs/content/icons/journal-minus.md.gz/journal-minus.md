---
title: Journal minus
categories:
  - Files and folders
tags:
  - file
  - folder
  - journal
  - notebook
---
