---
title: Journal richtext
categories:
  - Files and folders
tags:
  - file
  - folder
  - journal
  - notebook
---
