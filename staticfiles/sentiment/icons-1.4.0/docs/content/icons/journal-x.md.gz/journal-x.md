---
title: Journal x
categories:
  - Files and folders
tags:
  - file
  - folder
  - journal
  - notebook
  - remove
  - delete
---
