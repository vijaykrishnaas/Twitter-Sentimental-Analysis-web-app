---
title: List checked
categories:
  - Typography
tags:
  - text
  - type
  - justify
  - alignment
  - checklist
  - done
---
