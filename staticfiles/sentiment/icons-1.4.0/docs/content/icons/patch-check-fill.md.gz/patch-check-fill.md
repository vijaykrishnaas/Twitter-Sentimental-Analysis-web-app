---
title: Patch check fill
categories:
  - Badges
tags:
  - verified
  - checkmark
  - certified
aliases:
  - /icons/patch-check-fll/
---
