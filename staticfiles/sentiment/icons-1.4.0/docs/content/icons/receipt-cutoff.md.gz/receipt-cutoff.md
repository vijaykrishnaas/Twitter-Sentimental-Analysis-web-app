---
title: Receipt cutoff
layout: icon
categories:
  - Commerce
tags:
  - receipt
  - invoice
  - sale
  - purchase
---
