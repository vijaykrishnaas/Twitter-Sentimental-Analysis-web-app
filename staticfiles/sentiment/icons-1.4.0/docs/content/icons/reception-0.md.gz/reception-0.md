---
title: Reception 0
categories:
  - Communications
tags:
  - reception
  - cellphone
  - mobile
  - carrier
  - network
---
