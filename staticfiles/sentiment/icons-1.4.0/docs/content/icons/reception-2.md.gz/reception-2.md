---
title: Reception 2
categories:
  - Communications
tags:
  - reception
  - cellphone
  - mobile
  - carrier
  - network
---
