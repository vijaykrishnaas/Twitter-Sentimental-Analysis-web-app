---
title: Reception 3
categories:
  - Communications
tags:
  - reception
  - cellphone
  - mobile
  - carrier
  - network
---
