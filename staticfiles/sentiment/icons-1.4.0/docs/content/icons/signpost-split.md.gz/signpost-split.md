---
title: Signpost split
categories:
  - Real world
tags:
  - milestone
  - sign
  - road sign
  - street sign
  - directions
---
