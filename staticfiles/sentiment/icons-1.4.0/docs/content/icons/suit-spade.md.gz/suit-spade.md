---
title: Suit spade
categories:
  - Entertainment
tags:
  - card
  - cards
  - suit
  - deck
  - gambling
---
