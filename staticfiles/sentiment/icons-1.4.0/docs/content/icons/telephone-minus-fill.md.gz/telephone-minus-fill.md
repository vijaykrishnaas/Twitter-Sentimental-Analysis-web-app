---
title: Telephone minus fill
categories:
  - Communications
tags:
  - telephone
  - phone
  - call
---
