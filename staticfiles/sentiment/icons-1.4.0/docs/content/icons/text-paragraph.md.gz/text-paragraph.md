---
title: Text paragraph
categories:
  - Typography
tags:
  - text
  - type
  - paragraph
  - copy
---
