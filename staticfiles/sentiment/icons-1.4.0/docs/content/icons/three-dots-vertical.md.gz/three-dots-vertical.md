---
title: Three dots vertical
categories:
  - Controls
tags:
  - kebab
  - more
  - ellipsis
  - overflow
  - menu
---
