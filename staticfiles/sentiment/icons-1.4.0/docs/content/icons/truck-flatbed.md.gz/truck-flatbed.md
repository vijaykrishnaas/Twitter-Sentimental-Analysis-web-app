---
title: Truck flatbed
layout: icon
categories:
  - Commerce
tags:
  - trucking
  - shipping
  - shipment
  - transport
  - deliver
  - delivery
---
