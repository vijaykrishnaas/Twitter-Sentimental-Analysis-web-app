---
title: X circle
categories:
  - Alerts, warnings, and signs
tags:
  - x
  - delete
  - reset
  - clear
  - cancel
  - close
  - exit
---
