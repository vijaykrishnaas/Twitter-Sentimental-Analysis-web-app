---
title: X square
categories:
  - Alerts, warnings, and signs
tags:
  - x
  - delete
  - reset
  - clear
  - cancel
  - close
  - exit
---
